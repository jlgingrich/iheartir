import click
import logging

@click.group()
@click.option('-v', '--verbose', type=click.BOOL, is_flag=True)
def cli(verbose):
    if (verbose):
        level = logging.DEBUG
        logger = logging.getLogger()
        logger.setLevel(level)
        for handler in logger.handlers:
            handler.setLevel(level)


@cli.command()
@click.argument('search_string', nargs=1)
def search(search_string):
    '''Performs a search for matching radio station on all stream providers'''
    pass
    

@cli.command()
@click.argument('url', nargs=1)
def get(url):
    '''Gets information about the radio station from the provided url'''
    pass

@cli.command()
def providers():
    '''Lists the avaliable search providers for radio streams'''
    pass