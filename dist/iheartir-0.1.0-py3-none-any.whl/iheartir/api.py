import typing
from importlib.metadata import entry_points

def get_providers():
    '''Loads all entry points registered as a provider, confirms that it matches the protocol, and loads it'''
    discovered_plugins = entry_points().get('iheartir.providers')
    providers = {}
    for entry_point in discovered_plugins:
        providers[entry_point.name] = entry_point.load()
    return providers

def search_stations():
    '''Performs a search for matching radio station on all stream providers'''
    logging.debug("Querying providers for best results")
    results = []
    for provider in get_providers():
        results += provider.search(search_string)
    for station in results:
        click.echo("%s: %s" % (station.name, station.url))
    if len(results)==0:
        logging.warn("No matching stations returned")
    return results

def get_stations():
    '''Gets information about the radio station from the provided url'''
    logging.debug("Beginning search for matching provider")
    for provider in get_providers():
        if (provider.match(url)):
            logging.info("Found matching provider: %s" % provider)
            click.echo(provider.get(url))
            break
    else:
        logging.warn("Unable to find matching provider")
    return results